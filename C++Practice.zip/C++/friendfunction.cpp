#include <iostream>
using namespace std;

class A {
    int a, b;
public:
    void input() {
        cin >> a >> b;
    }
    friend int sum(A);
};

int sum(A obj) {
    return obj.a + obj.b;
}

int main() {
    A obj;
    obj.input();
    cout << "Sum = " << sum(obj);
    return 0;
}