#include <iostream>
using namespace std;

int main() {
    int x, n, result = 1;
    cin >> x >> n;

    for (int i = 0; i < n; i++)
        result *= x;

    cout << "Result = " << result;
    return 0;
}