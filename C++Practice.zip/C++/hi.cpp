#include <iostream>
using namespace std;

// Node structure
struct Node {
    int data;
    Node* next;
};

// Function to create a new node
Node* createNode(int data) {
    Node* newNode = new Node();
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

// Function to insert at end
Node* insertEnd(Node* head, int data) {
    Node* newNode = createNode(data);
    
    if (head == NULL)
        return newNode;

    Node* temp = head;
    while (temp->next != NULL)
        temp = temp->next;

    temp->next = newNode;
    return head;
}

// Function to merge two lists
Node* mergeLists(Node* head1, Node* head2) {
    if (head1 == NULL) return head2;
    
    Node* temp = head1;
    while (temp->next != NULL)
        temp = temp->next;

    temp->next = head2;
    return head1;
}

// Function to print list
void printList(Node* head) {
    while (head != NULL) {
        cout << head->data << " -> ";
        head = head->next;
    }
    cout << "NULL";
}

// Main function
int main() {
    Node* list1 = NULL;
    Node* list2 = NULL;

    // First list: 1 -> 2 -> 3
    list1 = insertEnd(list1, 1);
    list1 = insertEnd(list1, 2);
    list1 = insertEnd(list1, 3);

    // Second list: 4 -> 5 -> 6
    list2 = insertEnd(list2, 4);
    list2 = insertEnd(list2, 5);
    list2 = insertEnd(list2, 6);

    // Merge lists
    Node* merged = mergeLists(list1, list2);

    // Print merged list
    cout << "Merged List: ";
    printList(merged);

    return 0;
}