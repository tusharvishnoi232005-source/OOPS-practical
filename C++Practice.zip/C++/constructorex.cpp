#include <iostream>
using namespace std;

class A {
public:
    A() { cout << "Constructor Called"; }
};

int main() {
    A obj;
    return 0;
}