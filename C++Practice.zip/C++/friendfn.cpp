#include <iostream>
using namespace std;

class A {
    int x = 5;
    friend void show(A);
};

void show(A obj) {
    cout << obj.x;
}

int main() {
    A obj;
    show(obj);
    return 0;
}