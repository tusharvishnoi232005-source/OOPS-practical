#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ifstream f("file.txt");
    string s;
    getline(f, s);
    cout << s;
    return 0;
}