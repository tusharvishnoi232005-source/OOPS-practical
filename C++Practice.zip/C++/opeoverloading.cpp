#include <iostream>
using namespace std;

class A {
public:
    int x;
    A operator+(A obj) {
        A temp;
        temp.x = x + obj.x;
        return temp;
    }
};

int main() {
    A a, b, c;
    a.x = 2;
    b.x = 3;
    c = a + b;
    cout << c.x;
    return 0;
}