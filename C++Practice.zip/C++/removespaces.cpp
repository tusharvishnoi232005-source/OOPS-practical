#include <iostream>
using namespace std;

int main() {
    string s;
    getline(cin >> ws, s);   // FIX

    for (char c : s) {
        if (c != ' ')
            cout << c;
    }

    return 0;
}