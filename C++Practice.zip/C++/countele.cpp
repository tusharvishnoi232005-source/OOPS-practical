#include <iostream>
using namespace std;

int main() {
    int n, count = 0;
    cin >> n;
    int a[100];

    for (int i = 0; i < n; i++) {
        cin >> a[i];
        if (a[i] > 10) count++;
    }

    cout << count;
    return 0;
}