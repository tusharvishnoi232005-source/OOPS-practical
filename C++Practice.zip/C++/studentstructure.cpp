#include <iostream>
using namespace std;

struct Student {
    int roll;
    string name;
    int marks;
};

int main() {
    Student s;
    cin >> s.roll >> s.name >> s.marks;

    cout << "Roll:" << s.roll << " Name:" << s.name << " Marks:" << s.marks;
    return 0;
}