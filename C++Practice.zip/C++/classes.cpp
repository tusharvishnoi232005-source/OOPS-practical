#include <iostream>
using namespace std;

class Rectangle {
public:
    int length, width;

    void input() {
        cin >> length >> width;
    }

    int area() {
        return length * width;
    }
};

int main() {
    Rectangle r;
    r.input();

    cout << "Area = " << r.area();
    return 0;
}