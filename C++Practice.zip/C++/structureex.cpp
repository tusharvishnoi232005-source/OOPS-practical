#include <iostream>
using namespace std;

struct S {
    int x;
};

int main() {
    S s;
    s.x = 10;
    cout << s.x;
    return 0;
}