#include <iostream>
using namespace std;

class A {
public:
    int x, y;

    A operator+(A obj) {
        A temp;
        temp.x = x + obj.x;
        temp.y = y + obj.y;
        return temp;
    }
};

int main() {
    A a, b, c;
    cin >> a.x >> a.y >> b.x >> b.y;

    c = a + b;
    cout << c.x << " " << c.y;
    return 0;
}