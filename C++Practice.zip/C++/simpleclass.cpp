#include <iostream>
using namespace std;

class A {
public:
    int a, b;
    void input() { cin >> a >> b; }
    void show() { cout << a + b; }
};

int main() {
    A obj;
    obj.input();
    obj.show();
    return 0;
}