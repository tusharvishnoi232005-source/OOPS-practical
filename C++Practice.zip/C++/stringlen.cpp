#include <iostream>
using namespace std;

int main() {
    string s;
    cin >> s;

    cout << "Length = " << s.length() << endl;
    return 0;
}